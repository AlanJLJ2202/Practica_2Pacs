﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOL
{
    public class Marca
    {
        public int idMarca { get; set; }

        public string descripcion { get; set; }

        public bool activo { get; set; }

        public Marca() { }
    }
}
